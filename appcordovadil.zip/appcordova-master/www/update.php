<?php
 include "db.php";
 if(isset($_POST['update']))
 {
 $id=$_POST['id'];
 $title=$_POST['title'];
 $duration=$_POST['type'];
 $price=$_POST['years'];
 $q=mysqli_query($con,"UPDATE `aplikasi` SET `title`='$title',`type`='$type',`years`='$years' where `id`='$id'");
 if($q)
 echo "success";
 else
 echo "error";
 }
 ?>