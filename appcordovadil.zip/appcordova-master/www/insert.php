<?php
 include "db.php";
 if(isset($_POST['insert']))
 {
 $title=$_POST['title'];
 $duration=$_POST['type'];
 $price=$_POST['years'];
 $q=mysqli_query($con,"INSERT INTO `aplikasi` (`title`,`type`,`years`) VALUES ('$title','$type','$years')");
 if($q)
  echo "success";
 else
  echo "error";
 }
 ?>