<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id12804657_padil","alief12345","id12804657_cordova") or die ("could not connect database");
?>